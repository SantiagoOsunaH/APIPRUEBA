﻿namespace APIPRUEBA.Models
{
    public class Login
    {
        public string? User
        {
            get;
            set;
        }
        public string? Password
        {
            get;
            set;
        }
    }
}
