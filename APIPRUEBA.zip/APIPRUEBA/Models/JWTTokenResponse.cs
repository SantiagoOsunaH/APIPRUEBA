﻿namespace APIPRUEBA.Models
{
    public class JWTTokenResponse { 
    public string? Token
    {
        get;
        set;
    }
        public string? ValidIssuer { get; set; }
        public string? ValidAudience { get; set; }
        public string? Secret { get; set; }
    }
}
